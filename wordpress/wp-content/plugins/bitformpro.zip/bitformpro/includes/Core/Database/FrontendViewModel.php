<?php

namespace BitCode\BitFormPro\Core\Database;

use BitCode\BitForm\Core\Database\Model;

class FrontendViewModel extends Model
{
    protected static $table = 'bitforms_frontend_views';
}

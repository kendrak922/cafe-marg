<?php
/**
 * @license GPL-2.0-only
 *
 * Modified on 30-June-2025 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitCode\BitFormPro\Dependencies\Mpdf\Css;

class Border
{

	const ALL = 15;
	const TOP = 8;
	const RIGHT = 4;
	const BOTTOM = 2;
	const LEFT = 1;
}

export function getPortfolioLayouts(state) {
	return state.layouts;
}

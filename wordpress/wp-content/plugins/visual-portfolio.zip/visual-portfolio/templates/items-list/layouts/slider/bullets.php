<?php
/**
 * Slider layout bullets.
 *
 * @var $options
 * @var $style_options
 *
 * @package visual-portfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="vp-portfolio__items-bullets"></div>
